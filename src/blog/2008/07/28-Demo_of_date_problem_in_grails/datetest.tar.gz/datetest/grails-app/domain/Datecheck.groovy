class Datecheck {
      Date testDate

    static constraints = {
        testDate(nullable: true, validator: {val ->
            if (!val)
                return true // catches NULL and ''
            val > new Date()
        })
    }
      
}
