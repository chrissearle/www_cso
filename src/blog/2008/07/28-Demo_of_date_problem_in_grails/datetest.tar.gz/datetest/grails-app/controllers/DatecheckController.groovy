class DatecheckController {
    def defaultAction = "add"

    def add = {
        def datecheck = new Datecheck()

        def startYear = Calendar.getInstance().get(Calendar.YEAR)
        def endYear = startYear + 2

        [datecheck: datecheck, years: startYear..endYear]
    }

    def save = {
        println "In save: Params = ${params}"

        def datecheck = new Datecheck(params)

        println "In save: datecheck.testDate = ${datecheck.testDate}"

        if (!datecheck.hasErrors() && datecheck.save()) {
            redirect(action: show, id: datecheck.id)
        } else {
            render(view: 'add', model: [datecheck: datecheck])
        }
    }

    def show = {
        def datecheck = Datecheck.get(params.id)

        [datecheck: datecheck]
    }

}
