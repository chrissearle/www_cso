class DatecheckTests extends GroovyTestCase {

    void testSomething() {

    }
}
