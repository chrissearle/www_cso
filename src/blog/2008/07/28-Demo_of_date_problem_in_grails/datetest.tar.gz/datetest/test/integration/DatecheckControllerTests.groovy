class DatecheckControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
